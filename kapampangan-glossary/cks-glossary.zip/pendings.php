<?php 
include 'authentication.php'
 ?>
<html>
    <head>
        <title>CKS Glossary</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+SC:wght@300;400;500;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/pending-posts.css" />
    </head>
    <script>
          $(document).ready(function(){
            $('.update-btn').on('click', function(){
                $('#updateModal').modal('show');

                    $tr = $(this).closest('tr');
                    
                    var data = $tr.children("td").map(function(){
                        return $(this).text();
                    }).get();

                    console.log(data);

                    $('#update_id').val(data[0]);
                    $('#update_eword').val(data[1]);
                    $('#update_kword').val(data[2]);
                    $('#update_author').val(data[3]);
                    $('#update_email').val(data[4]);
            });

            $('.delete-btn').on('click', function(){
                $('#deleteModal').modal('show');

                $tr = $(this).closest('tr');
                    
                    var data = $tr.children("td").map(function(){
                        return $(this).text();
                    }).get();

                    console.log(data);

                    $('#delete_id').val(data[0]);
                    $('#delete_eword').val(data[1]);
                    $('#delete_kword').val(data[2]);
                    $('#delete_author').val(data[3]);
            });

            $('.approve-btn').on('click', function(){
                $('#approveModal').modal('show');

                $tr = $(this).closest('tr');
                    
                    var data = $tr.children("td").map(function(){
                        return $(this).text();
                    }).get();

                    console.log(data);

                    $('#approve_id').val(data[0]);
                    $('#approve_eword').val(data[1]);
                    $('#approve_kword').val(data[2]);
                    $('#approve_author').val(data[3]);
                    $('#approve_email').val(data[4]);
            });
       });
    </script>
    <body>
        <div class='left-section'>
            <div class="upper-left">
                <a href="/kapampangan-glossary/dashboard" class='home-link'>
                    <img src='assets/cks-logo.png' alt="CKS LOGO" class='header-logo'>
                        <h3 class='header-h3'>Center for <br> Kapampangan <br>Studies</h3>
                </a>
            </div>
            <div class="upper-mid">
                <nav>
                    <a href="/kapampangan-glossary/dashboard" class='nav-link' id='odd'><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
                    <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z"/>
                    </svg> Dashboard</a>
                    <div style="border-top: 1px solid white; width: 90%; margin: auto;"></div>
                    <a href="/kapampangan-glossary/collection" class='nav-link' id='even'><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-journal-album" viewBox="0 0 16 16">
                    <path d="M5.5 4a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5v-5a.5.5 0 0 0-.5-.5h-5zm1 7a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3z"/>
                    <path d="M3 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-1h1v1a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v1H1V2a2 2 0 0 1 2-2z"/>
                    <path d="M1 5v-.5a.5.5 0 0 1 1 0V5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0V8h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0v.5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1z"/>
                    </svg> Library</a>
                    <div style="border-top: 1px solid white; width: 90%; margin: auto;"></div>
                    <a href="/kapampangan-glossary/pending-posts" class='nav-link' id='odd'><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-square" viewBox="0 0 16 16">
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                    <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12z"/>
                    </svg> Pending Posts</a>
                    <div style="border-top: 1px solid white; width: 90%; margin: auto;"></div>
                    <a href="/kapampangan-glossary/admin-users" class='nav-link' id='odd'><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-square" viewBox="0 0 16 16">
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                    <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12z"/>
                    </svg> Admin</a>

                </nav>
            </div>
            <div class="upper-bottom">
                <a href="logout.php" id="logout">Logout</a>
            </div>
        </div>
        <div class='right-section'>
            <h3>Pending Posts</h3>
            <div style="border-top: 2px solid #333333; margin-bottom: 20px; margin-top: 30px; width: 96%;"></div>
            <div class="pending-container">
                <div class="container-fluid" id='glossary-table'>
                    <?php 
                        include "connect.php";
                        $pending_query = mysqli_query($connection, "SELECT * FROM tbl_glossary WHERE status = 'Pending' ORDER BY word ASC");
                    ?>
                    <div class="table-responsive">
                        <table class="table table-hover" id="table-data">
                            <thead >
                                <tr>
                                <th scope="col" hidden="hidden">#</th>
                                <th scope="col">Word</th>
                                <th scope="col">Kapampangan</th>
                                <th scope="col">Post Author</th>
                                <th scope="col">Email</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <?php
                                if ($pending_query ) {    
                                    foreach($pending_query as $row){
                            ?>
                            <tbody>
                                <tr>
                                <td scope="row" hidden="hidden"><?php echo $row['id']; ?></td>
                                <td><?php echo $row['word']; ?></td>
                                <td><?php echo $row['kapampangan']; ?></td>
                                <td><?php echo $row['post_author']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td>
                                    <button class="btn btn-danger delete-btn" ><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z"/>
                            </svg></button>
                                    <button class="btn btn-warning update-btn"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg></button>
                                    <button class="btn btn-success approve-btn">Approve</button>
                                </td>
                                </tr>
                            </tbody>
                            <?php }
                        }?>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- ###################################### DELETE MODAL  ############################################## -->

<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Confirm Deletion</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="delete.php" method="POST">
            <div class="form-group">
                <label for="exampleInputPassword1">ID</label>
                <input type="text" class="form-control" name="delete_id" id='delete_id' readonly>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Word</label>
                <input type="text" class="form-control" name="delete_eword" id='delete_eword' readonly>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Kapampangan</label>
                <input type="text" class="form-control" name="delete_kword" id='delete_kword' readonly>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Author</label>
                <input type="text" class="form-control" name="delete_author" id='delete_author' readonly>
            </div>
            <div style='display: flex; justify-content: space-between;'>
                <button type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
                <button type="submit" name="delete" class="btn btn-danger">Yes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- ######################################  UPDATE RECORD MODAL  ############################################## -->
            <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Update Post</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="update.php" method="POST">
                            <div class="form-group">
                                <label for="exampleInputPassword1">ID</label>
                                <input type="text" class="form-control" name="update_id" id='update_id' readonly>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">English</label>
                                <input type="text" class="form-control" placeholder="Enter Word" name="update_eword" id='update_eword'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Kapampangan</label>
                                <input type="text" class="form-control" placeholder="Enter Word" name="update_kword" id='update_kword'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Post Author</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="update_author" id='update_author'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Email</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="update_email" id='update_email'>
                            </div>
                            <div class="form-group">
                                <label for="inputState">Status</label>
                                <select id="inputState" class="form-control" name="update_status">
                                    <option selected>Approved</option>
                                    <option>Pending</option>
                                </select>
                            </div>
                            <div style='display: flex; justify-content: space-between;'>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-success">Save</button>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>

<!-- ######################################  APPROVE RECORD MODAL  ############################################## -->
<div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirm Approve Post</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="exampleInputPassword1">ID</label>
                                <input type="text" class="form-control" name="approve_id" id='approve_id' readonly>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">English</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="approve_eword" id='approve_eword'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Kapampangan</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="approve_kword" id='approve_kword'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Post Author</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="approve_author" id='approve_author'>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Email</label>
                                <input disabled type="text" class="form-control" placeholder="Enter Word" name="approve_email" id='approve_email'>
                            </div>
                            <div class="form-group">
                                <label for="inputState">Status</label>
                                <select disabled id="inputState" class="form-control" name="approve_status">
                                    <option>Pending</option>
                                </select>
                            </div>
                            <div style='display: flex; justify-content: space-between;'>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" name="approve" class="btn btn-success">Approve</button>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>
            <?php 
            
                if(isset($_POST['approve'])){
                    $id = $_POST['approve_id'];
                    
                    $query = "UPDATE tbl_glossary SET status='Approved' WHERE id = '$id'";

                    $result = mysqli_query($connection, $query);

                    if($result)
                    {
                        echo "<script> alert('Post Approved!');</script>";
                        echo "<script> window.location.href = '/kapampangan-glossary/pending-posts'</script>";
                    }
                    else{
                        echo "<script> alert('Post Approval Failed!');</script>";
                    }
                }
            ?>
    </body>
</html>